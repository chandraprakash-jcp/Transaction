package servlet;


import objects.Transaction;
import org.json.JSONObject;
import peristance.DMLOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;

public class TransactionProcessor extends HttpServlet
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        return;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException
    {
        try
        {
            Transaction transactionObj = getDecodedTransaction(request.getParameter("transactionObj"));
            DMLOperation dmlOperation = new DMLOperation();
            dmlOperation.persistToDataBase(transactionObj);
        }
        catch (Exception e)
        {
            throw new ServletException("Transaction processing Failed",e);
        }
    }

    private Transaction getDecodedTransaction(String encodedTransaction)
    {
        String decodedString = URLDecoder.decode(encodedTransaction);
        JSONObject transaction = new JSONObject(decodedString);
        long accountNumber = Long.parseLong(transaction.getString("AccountNumber"));
        String type = transaction.getString("Type");
        double amount = Double.parseDouble(transaction.getString("Amount"));
        String currency = transaction.getString("Currency");
        long accountFrom = Long.parseLong(transaction.getString("AccountFrom"));
        Transaction transactionObj = new Transaction(accountNumber, type, amount, currency, accountFrom);
        return transactionObj;
    }
}
