/*
 * $Id: $
 */
package peristance;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnectionUtil
{
    private static final Logger LOGGER = Logger.getLogger(DBConnectionUtil.class.getName());

    private static final String DRIVERNAME = "com.mysql.jdbc.Driver"; //No I18N
    private static final String USERNAME = "root"; //No I18N
    private static final String PASSWORD = "";//No I18N


    public static Connection getAgentDBConnection()
    {
        Connection conn = null;
        try {
            Class.forName(DRIVERNAME);
            String dbUrl = "jdbc:mysql://localhost:3306/transaction"; // No I18N
            conn = DriverManager.getConnection(dbUrl, USERNAME, PASSWORD);
	        conn.setAutoCommit(false);
        }
        catch (Exception e) {
            LOGGER.log(Level.SEVERE,"exception while getting agent connection",e); // No I18N
        }
        return conn;
    }

    public static void closeConnection(Connection conn)
    {
        try {
        	if(conn != null) {
        		conn.close();
        	}
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE,"exception while closing agent connection",e); // No I18N
        }
    }

    public static void closeStatement(Statement stmt) {
    	try {
    		if(stmt != null) {
    			stmt.close();
    		}
    	}
    	catch(Exception e) {
            LOGGER.log(Level.SEVERE,"exception while closing agent statement",e); // No I18N
    	}
    }

    public static void closeResultSet(ResultSet rs)
    {
        try {
        	if(rs != null) {
        		rs.close();
        	}
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE,"exception while closing results set",e); // No I18N
        }
    }
}
