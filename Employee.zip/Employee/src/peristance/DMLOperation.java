package peristance;

import objects.Transaction;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DMLOperation
{
    public void persistToDataBase(Transaction transaction) throws SQLException
    {
        Connection agentDBConnection = DBConnectionUtil.getAgentDBConnection();
        Statement statement = agentDBConnection.createStatement();

        StringBuilder insertQuery = new StringBuilder();
        insertQuery.append("Insert into Transaction values (");
        insertQuery.append(transaction.getAccountNumber());
        insertQuery.append("," + transaction.getType());
        insertQuery.append("," + transaction.getAmount());
        insertQuery.append("," + transaction.getCurrency());
        insertQuery.append("," + transaction.getAccountFrom());

        statement.executeUpdate(insertQuery.toString());
        DBConnectionUtil.closeStatement(statement);
        DBConnectionUtil.closeConnection(agentDBConnection);
    }
}
