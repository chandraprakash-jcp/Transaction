package core;

import objects.Transaction;
import servlet.SendTransaction;

import java.io.IOException;

public class TransactionCreator
{
    public static void main(String[] args) throws IOException
    {
        // dummy transaction creation
        Transaction transaction = new Transaction(12345679l,"Credit",20000.45,"INR",9897998585l);
        SendTransaction.sendPOST(transaction);
    }
}
