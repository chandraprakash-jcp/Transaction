package objects;

public class Transaction
{
    private long accountNumber;
    private String type;
    private double amount;
    private String currency;
    private long accountFrom;

    public Transaction(long accountNumber,String type,double amount,String currency,long accountFrom)
    {
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
        this.currency = currency;
        this.accountFrom = accountFrom;
    }

    public long getAccountNumber()
    {
        return accountNumber;
    }

    public long getAccountFrom()
    {
        return accountFrom;
    }

    public String getType()
    {
        return type;
    }

    public double getAmount()
    {
        return amount;
    }

    public String getCurrency()
    {
        return currency;
    }
}

